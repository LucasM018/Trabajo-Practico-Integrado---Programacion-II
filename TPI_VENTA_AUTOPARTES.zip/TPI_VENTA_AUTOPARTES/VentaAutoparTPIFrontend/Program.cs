
var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

// Habilita el acceso a los archivos est�ticos.
app.UseDefaultFiles();
app.UseStaticFiles();

app.Run();
